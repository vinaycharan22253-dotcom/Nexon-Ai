# NEXUS AI Hybrid Android app — source project

## What works in this build
- Native Android launcher wrapping a local HTML app.
- Live Gemini text chat after you enter your own API key in Settings.
- Local on-device memories, goals, chat history.
- Goal suggestions from the AI; saving goals is user-controlled.
- Export and clear local data.
- No external actions, payments, messaging or file operations are executed.

## Build APK without a computer (GitHub Actions)
1. Sign in to GitHub in your Android browser and create a **private** repository, e.g. `nexus-ai`.
2. Extract this ZIP on your phone.
3. Upload the extracted project files and folders to the repository root (keep `.github/workflows/build-apk.yml`).
   Do not upload your Gemini API key.
4. Open the repository's **Actions** tab. Select **Build NEXUS AI APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `NEXUS-AI-debug-apk`.
6. Extract the artifact ZIP; install `app-debug.apk` on your OPPO. Android may ask you to allow installs from your browser/file manager.

## Connect the AI
1. Create a Gemini API key at https://aistudio.google.com/app/apikey
2. Install and open NEXUS AI.
3. Go to Settings, paste the key and tap Save key, then Test connection.
4. Return to Chat and ask a question.

## Important security and cost notes
- This app calls Gemini directly from the phone. A key stored in a client app can be extracted. Use only for personal testing; do not distribute this APK with a key embedded.
- Do not commit API keys to GitHub. The key is entered after installation and stored locally by the app.
- Gemini API free-tier access has quotas and can change. Google documents that free-tier content may be used to improve products; review current terms before entering private or sensitive information.
- This version does not include Google Search grounding, autonomous background tasks, or a local GGUF model. It has offline local memory and goal storage; cloud AI chat requires internet.
- API key is stored in WebView local storage, not Android Keystore. This is a starter build, not a security-audited production app.
- This environment did not compile, sign or install-test the APK. GitHub Actions builds a debug APK; it is not Play Store release-signed.
