package com.nexusai.personal;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
  private WebView web;
  private final ExecutorService network = Executors.newSingleThreadExecutor();

  private class NexusBridge {
    @JavascriptInterface
    public void request(String apiKey, String body, String callbackId) {
      network.execute(() -> {
        HttpURLConnection conn = null;
        String response = "";
        boolean success = false;
        try {
          URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent");
          conn = (HttpURLConnection) url.openConnection();
          conn.setRequestMethod("POST");
          conn.setConnectTimeout(20000);
          conn.setReadTimeout(60000);
          conn.setDoOutput(true);
          conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
          conn.setRequestProperty("x-goog-api-key", apiKey);
          byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
          try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }
          int code = conn.getResponseCode();
          InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
          if (stream != null) {
            StringBuilder out = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
              String line;
              while ((line = br.readLine()) != null) out.append(line);
            }
            response = out.toString();
          }
          success = code >= 200 && code < 300;
        } catch (Exception e) {
          try { response = new JSONObject().put("error", new JSONObject().put("message", e.getMessage())).toString(); }
          catch (Exception ignored) { response = e.toString(); }
        } finally {
          if (conn != null) conn.disconnect();
        }
        final boolean ok = success;
        final String result = response;
        runOnUiThread(() -> {
          if (web != null) {
            String js = "window.nexusNativeResult(" + JSONObject.quote(callbackId) + "," + ok + "," + JSONObject.quote(result) + ");";
            web.evaluateJavascript(js, null);
          }
        });
      });
    }
  }

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(8,13,24));
    getWindow().setNavigationBarColor(Color.rgb(8,13,24));
    web = new WebView(this);
    setContentView(web);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setSupportZoom(false);
    web.addJavascriptInterface(new NexusBridge(), "NexusBridge");
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    web.loadUrl("file:///android_asset/index.html");
  }

  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }

  @Override protected void onDestroy() {
    if (web != null) { web.destroy(); web = null; }
    network.shutdownNow();
    super.onDestroy();
  }
}
